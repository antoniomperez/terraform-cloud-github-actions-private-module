curl \
  --header "Authorization: Bearer s9Jxrm2LRlasGw.atlasv1.lgOgnhkabykgvPlRo7TAnwE6NlMnljRP3GhWTpbNR7JTRCZtZrw1LG7ei6vKR580Uis" \
  --header "Content-Type: application/vnd.api+json" \
  --request POST \
  --data @payload.json \
  https://app.terraform.io/api/v2/organizations/amarquez/registry-modules