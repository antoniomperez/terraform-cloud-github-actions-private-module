curl \
  --header "Authorization: Bearer s9Jxrm2LRlasGw.atlasv1.lgOgnhkabykgvPlRo7TAnwE6NlMnljRP3GhWTpbNR7JTRCZtZrw1LG7ei6vKR580Uis" \
  --header "Content-Type: application/vnd.api+json" \
  --request POST \
  --data @versionpayload.json \
  https://app.terraform.io/api/v2/organizations/amarquez/registry-modules/private/amarquez/terraform-aws-remote-state-s3/aws/versions