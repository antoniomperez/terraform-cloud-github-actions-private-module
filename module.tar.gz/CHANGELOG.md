# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## 0.1.0 (2022-03-03)


### Features

* add dynamodb table for lock the remote state ([8aa9d6e](https://github.com/antoniomperez/terraform-modules/commit/8aa9d6e8ff4e3e4a110512f43701b07ba5a682a2))
* add remote bucket module to store the state in S3 ([3aa2434](https://github.com/antoniomperez/terraform-modules/commit/3aa243425f2b4e725cefbe52f69786fd57fc6661))
